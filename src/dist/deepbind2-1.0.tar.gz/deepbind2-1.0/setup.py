from distutils.core import setup
setup(name='deepbind2',
      version='1.0',
      py_modules=['deepbind2'],
      )